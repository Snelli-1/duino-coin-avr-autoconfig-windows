# Mitwirken

1. Forke das Repository.
2. Erstelle einen eigenen Branch.
3. Committe niemals EXE-Dateien, Mining Keys oder persönliche Konfigurationen.
4. Führe nach PowerShell-Änderungen PSScriptAnalyzer aus.
5. Erstelle einen Pull Request mit einer kurzen Testbeschreibung.
