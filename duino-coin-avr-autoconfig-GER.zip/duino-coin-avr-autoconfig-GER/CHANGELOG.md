# Änderungsprotokoll

## 1.0.0 - 2026-11-17

- Portable Stammordner-Erkennung.
- Dynamische Erkennung serieller Windows-Ports.
- Ausschluss serieller Bluetooth-Ports.
- Dynamische Erzeugung von `avrport` und `identifier`.
- Standardwert `mining_key=None`.
- Restarter-EXE als Standard-Starter.
- Konfigurationssicherung mit Zeitstempel.
