# Duino-Coin AVR AutoConfig für Windows

Ein einsteigerfreundliches, portables Hilfsprogramm für den Duino-Coin AVR Miner 4.3 unter Windows.

## Funktionen

1. Listet aktive serielle Windows-Ports auf.
2. Schließt serielle Bluetooth-Verbindungen aus.
3. Sortiert USB-Seriell-Ports nach COM-Nummer.
4. Erstellt dynamisch `Duino-Coin AVR Miner 4.3/Settings.cfg`.
5. Vergibt fortlaufende Kennungen `1,2,3...N` für erkannte Ports.
6. Startet nach der Konfiguration standardmäßig `Duino_AVR_Miner_restarter_v1_1.exe`.
7. Erstellt vor dem Ersetzen einer bestehenden Konfiguration eine Sicherung mit Zeitstempel.

## Wichtig

Dieses Repository enthält **keine** Duino-Coin-EXE- oder DLL-Dateien. Lade die offizielle Duino-Coin-Windows-Version separat herunter. Veröffentliche niemals deine persönliche `Setup_Settings.txt`, `Settings.cfg`, deinen Benutzernamen oder Mining Key.

## Voraussetzungen

- Windows 10 oder Windows 11
- Windows PowerShell 5.1 oder neuer
- Installierte USB-Seriell-Treiber
- Offizielles Duino-Coin AVR Miner 4.3 Windows-Paket
- `Duino_AVR_Miner_restarter_v1_1.exe` im Stammordner, wenn der Standard-Starter verwendet wird

## Installation

1. Lade dieses Repository herunter oder klone es.
2. Kopiere die Dateien in den Stammordner `Duino-Coin_4.3_windows`.
3. Erstelle deine lokale Einstellungsdatei:

```bat
copy Setup_Settings.example.txt Setup_Settings.txt
```

4. Bearbeite `Setup_Settings.txt` und ersetze `YOUR_DUINO_USERNAME`.
5. Starte `Frissit_LGT8F328P_portok.bat`.

## Erwartete Ordnerstruktur

```text
Duino-Coin_4.3_windows\
├── Frissit_LGT8F328P_portok.bat
├── Update-DuinoPorts.ps1
├── Setup_Settings.txt
├── Duino_AVR_Miner_restarter_v1_1.exe
└── Duino-Coin AVR Miner 4.3\
    ├── Settings.cfg
    └── Translations.json
```

## Konfigurationsbeispiel

```ini
username=YOUR_DUINO_USERNAME
donate=1
language=english
debug=n
soc_timeout=10
avr_timeout=10
discord_presence=y
periodic_report=300
mining_key=None
miner_exe=Duino_AVR_Miner_restarter_v1_1.exe
```

Für einen anderen Starter trage den exakten EXE-Dateinamen bei `miner_exe` ein.

## Sicherheit

Die enthaltene `.gitignore` schließt persönliche Einstellungen, erzeugte Konfigurationen, Sicherungen, EXE- und DLL-Dateien aus. Prüfe vor jedem öffentlichen Commit die vorgemerkten Dateien.

## Fehlerbehebung

- **Keine seriellen Ports gefunden:** Prüfe den Windows-Geräte-Manager, das USB-Kabel und den USB-Seriell-Treiber.
- **Starter nicht gefunden:** Prüfe den exakten `miner_exe`-Dateinamen und lege die EXE im Stammordner ab.
- **PowerShell-Ausführungsrichtlinienfehler:** Die BAT-Datei verwendet `ExecutionPolicy Bypass` nur für den gestarteten Prozess und ändert keine Systemrichtlinie.

## Haftungsausschluss

Dies ist ein unabhängiges Community-Hilfsprogramm und keine offizielle Duino-Coin-Version. Duino-Coin und zugehörige Komponenten gehören den jeweiligen Rechteinhabern.

## Lizenz

Die Skripte in diesem Repository stehen unter der MIT-Lizenz. Siehe `LICENSE`.
