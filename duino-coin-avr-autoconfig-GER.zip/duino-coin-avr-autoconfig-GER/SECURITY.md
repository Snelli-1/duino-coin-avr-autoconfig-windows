# Sicherheitsrichtlinie

## Unterstützte Version

Es wird nur das neueste GitHub Release unterstützt.

## Sicherheitslücken melden

Erstelle kein öffentliches Issue mit Mining Key, personenbezogenen Daten oder ausnutzbaren Schwachstellen. Verwende die private Schwachstellenmeldung von GitHub.

## Geheimnisse

Committe niemals `Setup_Settings.txt`, `Settings.cfg`, Sicherungsdateien, EXE- oder DLL-Dateien. Die enthaltene `.gitignore` schließt diese standardmäßig aus.
