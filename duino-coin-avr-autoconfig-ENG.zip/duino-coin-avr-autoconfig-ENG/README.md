# Duino-Coin AVR AutoConfig for Windows

A beginner-friendly, portable helper for Duino-Coin AVR Miner 4.3 on Windows.

## Features

1. Lists active Windows serial ports.
2. Excludes Bluetooth serial links.
3. Sorts USB serial ports by COM number.
4. Dynamically creates `Duino-Coin AVR Miner 4.3/Settings.cfg`.
5. Assigns sequential identifiers `1,2,3...N` to detected ports.
6. Starts `Duino_AVR_Miner_restarter_v1_1.exe` by default after configuration.
7. Creates a timestamped backup before replacing an existing configuration.

## Important

This repository does **not** include Duino-Coin executables or DLL files. Download the official Duino-Coin Windows release separately. Never publish your personal `Setup_Settings.txt`, `Settings.cfg`, username, or mining key.

## Requirements

- Windows 10 or Windows 11
- Windows PowerShell 5.1 or newer
- Installed USB serial drivers
- Official Duino-Coin AVR Miner 4.3 Windows package
- `Duino_AVR_Miner_restarter_v1_1.exe` in the package root when using the default launcher

## Installation

1. Download or clone this repository.
2. Copy its files into the `Duino-Coin_4.3_windows` root folder.
3. Create your local settings file:

```bat
copy Setup_Settings.example.txt Setup_Settings.txt
```

4. Edit `Setup_Settings.txt` and replace `YOUR_DUINO_USERNAME`.
5. Run `Frissit_LGT8F328P_portok.bat`.

## Expected folder structure

```text
Duino-Coin_4.3_windows\
├── Frissit_LGT8F328P_portok.bat
├── Update-DuinoPorts.ps1
├── Setup_Settings.txt
├── Duino_AVR_Miner_restarter_v1_1.exe
└── Duino-Coin AVR Miner 4.3\
    ├── Settings.cfg
    └── Translations.json
```

## Configuration example

```ini
username=YOUR_DUINO_USERNAME
donate=1
language=english
debug=n
soc_timeout=10
avr_timeout=10
discord_presence=y
periodic_report=300
mining_key=None
miner_exe=Duino_AVR_Miner_restarter_v1_1.exe
```

To use another launcher, set its exact filename in `miner_exe`.

## Security

The included `.gitignore` excludes personal settings, generated configuration, backups, EXE files, and DLL files. Review staged files before every public commit.

## Troubleshooting

- **No serial ports found:** check Windows Device Manager, the USB cable, and the USB serial driver.
- **Launcher not found:** verify the exact `miner_exe` filename and place the EXE in the root folder.
- **PowerShell execution policy error:** the BAT uses `ExecutionPolicy Bypass` only for the launched process and does not modify the system policy.

## Disclaimer

This is an independent community helper and not an official Duino-Coin release. Duino-Coin and related components belong to their respective owners.

## License

The scripts in this repository are provided under the MIT License. See `LICENSE`.
