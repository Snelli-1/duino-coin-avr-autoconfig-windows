# Changelog

## 1.0.0 - 2026-11-17

- Portable root-folder handling.
- Dynamic Windows serial-port discovery.
- Bluetooth serial-port exclusion.
- Dynamic `avrport` and `identifier` generation.
- `mining_key=None` default.
- Restarter EXE as the default launcher.
- Timestamped configuration backups.
