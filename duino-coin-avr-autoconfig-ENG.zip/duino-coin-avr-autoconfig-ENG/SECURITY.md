# Security Policy

## Supported version

Only the latest GitHub Release is supported.

## Reporting a vulnerability

Do not open a public issue containing a mining key, personal data, or exploitable vulnerability. Use GitHub private vulnerability reporting.

## Secrets

Never commit `Setup_Settings.txt`, `Settings.cfg`, backup files, EXE files, or DLL files. The included `.gitignore` excludes them by default.
