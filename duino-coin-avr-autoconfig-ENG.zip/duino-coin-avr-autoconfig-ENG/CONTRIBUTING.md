# Contributing

1. Fork the repository.
2. Create a dedicated branch.
3. Never commit EXE files, mining keys, or personal configuration.
4. Run PSScriptAnalyzer after PowerShell changes.
5. Open a pull request with a short test description.
